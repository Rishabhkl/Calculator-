package com.jsb.calculator;

import android.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.jsb.calculator.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding binding;
    boolean equa = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        try {
            ActionBar actionBar = getActionBar();
            actionBar.setTitle("Calculator");
        }catch (Exception e){
            try {
                getSupportActionBar().setTitle("Calculator");
            }catch (Exception e2){}
        }


        binding.buttonZero.setOnClickListener(this);
        binding.buttonZero2.setOnClickListener(this);
        binding.buttonOne.setOnClickListener(this);
        binding.buttonTwo.setOnClickListener(this);
        binding.buttonThree.setOnClickListener(this);
        binding.buttonFour.setOnClickListener(this);
        binding.buttonFive.setOnClickListener(this);
        binding.buttonSix.setOnClickListener(this);
        binding.buttonSeven.setOnClickListener(this);
        binding.buttonEight.setOnClickListener(this);
        binding.buttonNine.setOnClickListener(this);
        binding.buttonClear.setOnClickListener(this);
        binding.buttonDeleteText.setOnClickListener(this);
        binding.buttonPercent.setOnClickListener(this);
        binding.buttonDivision.setOnClickListener(this);
        binding.buttonMultiplication.setOnClickListener(this);
        binding.buttonDot.setOnClickListener(this);
        binding.buttonSubtraction.setOnClickListener(this);
        binding.buttonAddition.setOnClickListener(this);
        binding.buttonEqual.setOnClickListener(this);
        binding.buttonAddition.setOnClickListener(this);

    }

    private void setNum(String num){
        if (equa){
            binding.textViewInputNumbers.setText("");
            equa = false;
        }
        binding.textViewInputNumbers.setText(binding.textViewInputNumbers.getText().toString()+num);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.button_zero:
                setNum("0");
                break;
            case R.id.button_zero2:
                setNum("00");
                break;
            case R.id.button_one:
                setNum("1");
                break;
            case R.id.button_two:
                setNum("2");
                break;
            case R.id.button_three:
                setNum("3");
                break;
            case R.id.button_four:
                setNum("4");
                break;
            case R.id.button_five:
                setNum("5");
                break;
            case R.id.button_six:
                setNum("6");
                break;
            case R.id.button_seven:
                setNum("7");
                break;
            case R.id.button_eight:
                setNum("8");
                break;
            case R.id.button_nine:
                setNum("9");
                break;
            case R.id.button_addition:
                setSine("+");
                break;
            case R.id.button_subtraction:
                setSine("-");
                break;
            case R.id.button_multiplication:
                setSine("x");
                break;
            case R.id.button_division:
                setSine("÷");
                break;
            case R.id.button_percent:
                setSine("%");
                break;
            case R.id.button_dot:
                setSine(".");
                break;
            case R.id.button_clear:
                binding.textViewInputNumbers.setText("");
                break;
            case R.id.button_delete_text:
                String v = binding.textViewInputNumbers.getText().toString();
                try {
                    binding.textViewInputNumbers.setText(v.substring(0,v.length()-1));
                }catch (Exception e){ }
                break;
            case R.id.button_equal:
                calculate();
                break;

        }
    }

    private void setSine(String sine){
        String v = binding.textViewInputNumbers.getText().toString();
        equa = false;
        if (binding.textViewInputNumbers.getText().toString().equals("") | binding.textViewInputNumbers.getText().toString() == null){
            if (sine.endsWith("-")){
                binding.textViewInputNumbers.setText(v+sine);
            }
        }else {
            if (v.endsWith("+") | v.endsWith("x") | v.endsWith("-") | v.endsWith("%") | v.endsWith("÷") | v.endsWith(".")){
                binding.textViewInputNumbers.setText(v.replace("+",sine).replace("-",sine).replace("%",sine).replace("x",sine).replace(".",sine).replace("÷",sine));
            }else {
                binding.textViewInputNumbers.setText(v+sine);
            }
        }
    }






    private void calculate(){
        String v = binding.textViewInputNumbers.getText().toString();

        if (v.isEmpty()){

        }else {

            if (chek_end(v)){

            }else {

                float result = 0;
                String absd = "";
                int statring = 0;

                for (int i = 0; v.length() > i; i++){
                    if (check_is_sine(String.valueOf(v.charAt(i)))){
                        absd = absd+"=jsb="+i;
                    }
                }

                absd = absd.substring(5);
                String[] absd2 = absd.split("=jsb=");

                try {
                    if (absd2.length == 1){
                        result = eq(v.substring(0,Integer.parseInt(absd2[0])),v.substring(Integer.parseInt(absd2[0])+1), String.valueOf(v.charAt(Integer.parseInt(absd2[0]))));
                    }
                    else {
                        String vvvvv = v;
                        boolean s = true;
                        while (s){
                            try {

                                String abcd22 = "";
                                for (int i = 0; vvvvv.length() > i; i++){
                                    if (check_is_sine(String.valueOf(vvvvv.charAt(i)))){
                                        abcd22 += i+"";
                                    }
                                }

                                String nn2;
                                try {
                                    nn2 = String.valueOf(abcd22.charAt(1));
                                }catch (Exception eee){
                                    nn2 = String.valueOf(vvvvv.length());
                                    s = false;
                                }
                                int nn = Integer.parseInt(nn2);
                                String cc = vvvvv.substring(0, nn);
                                vvvvv = vvvvv.substring(nn);

                                if (chek_start(cc)){
                                    String nnn2 = String.valueOf(abcd22.charAt(0));
                                    int nnn = Integer.parseInt(nnn2);
                                    result = eq(String.valueOf(result),cc.substring(nnn+1), String.valueOf(cc.charAt(nnn)));

                                }else {
                                    String nnn2 = String.valueOf(abcd22.charAt(0));
                                    int nnn = Integer.parseInt(nnn2);
                                    result = eq(cc.substring(0,nnn),cc.substring(nnn+1), String.valueOf(cc.charAt(nnn)));
                                }


                            }catch (Exception e){

                                e.printStackTrace();
                                s =false;
                                break;
                            }

                        }
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }

                equa = true;
                binding.textViewInputNumbers.setText(result+"");

            }
        }
    }


    private boolean chek_end(String v){
        if (v.endsWith("+") | v.endsWith("x") | v.endsWith("-") | v.endsWith("%") | v.endsWith("÷") | v.endsWith(".")){
            String abcd22 = "";
            for (int i = 0; v.length() > i; i++){
                if (check_is_sine(String.valueOf(v.charAt(i)))){
                    abcd22 += i+"";
                }
            }
            if (abcd22.length() <= 2){
                return false;
            }else {
                return true;
            }

        }else {
            try {
                float vv = Float.parseFloat(v);
                return true;
            }catch (Exception e){
                return false;
            }
        }
    }
    private boolean chek_start(String v){
        if (v.startsWith("+") | v.startsWith("x") | v.startsWith("-") | v.startsWith("%") | v.startsWith("÷") | v.startsWith(".")){
            return true;
        }else {

            return false;

        }
    }

    private boolean check_is_sine(String v){
        if (v.equals("+") | v.equals("x") | v.equals("-") | v.equals("%") | v.equals("÷")){
            return true;
        }else {
            return false;
        }
    }


    private float eq(String text1,String text2,String sineeeeeee){
        float t1 = Float.parseFloat(text1);
        float t2 = Float.parseFloat(text2);
        float result = 0;
        if (sineeeeeee.equals("+")){
            result = t1+t2;
        }else if (sineeeeeee.equals("-")){
            result = t1-t2;
        }else if (sineeeeeee.equals("x")){
            result = t1*t2;
        }else if (sineeeeeee.equals("÷")){
            result = t1/t2;
        }else if (sineeeeeee.equals("%")){
            float p = t1/100;
            float x = t2;
            result = p*x;
        }


        return result;
    }

}
